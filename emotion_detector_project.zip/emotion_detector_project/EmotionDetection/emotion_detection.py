"""Package-compatible import of the top-level detector."""
from emotion_detection import emotion_detector

__all__ = ["emotion_detector"]
