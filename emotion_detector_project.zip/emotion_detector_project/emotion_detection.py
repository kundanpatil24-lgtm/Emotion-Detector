"""Watson NLP emotion detection wrapper."""
import requests

EMOTION_URL = ("https://sn-watson-emotion.labs.skills.network/"
               "v1/watson.runtime.nlp.v1/NlpService/EmotionPredict")
HEADERS = {"grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"}


def _empty_result():
    return {"anger": None, "disgust": None, "fear": None, "joy": None,
            "sadness": None, "dominant_emotion": None}


def emotion_detector(text_to_analyze):
    """Analyze text and return five emotion scores plus dominant_emotion."""
    if not isinstance(text_to_analyze, str) or not text_to_analyze.strip():
        return _empty_result()
    try:
        response = requests.post(
            EMOTION_URL,
            json={"raw_document": {"text": text_to_analyze}},
            headers=HEADERS,
            timeout=30,
        )
    except requests.RequestException:
        return _empty_result()

    if response.status_code == 400:
        return _empty_result()
    response.raise_for_status()
    payload = response.json()
    predictions = payload.get("emotionPredictions", [])
    if not predictions:
        return _empty_result()
    emotions = predictions[0].get("emotion", {})
    result = {key: emotions.get(key) for key in ("anger", "disgust", "fear", "joy", "sadness")}
    numeric = {key: value for key, value in result.items()
               if isinstance(value, (int, float))}
    result["dominant_emotion"] = max(numeric, key=numeric.get) if numeric else None
    return result
