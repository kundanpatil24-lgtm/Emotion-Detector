"""Unit tests for emotion detection output and error handling."""
import unittest
from unittest.mock import Mock, patch
from emotion_detection import emotion_detector


class TestEmotionDetector(unittest.TestCase):
    @patch("emotion_detection.requests.post")
    def test_dominant_joy(self, post):
        response = Mock(status_code=200)
        response.json.return_value = {"emotionPredictions": [{"emotion": {
            "anger": 0.01, "disgust": 0.01, "fear": 0.02,
            "joy": 0.92, "sadness": 0.04}}]}
        post.return_value = response
        result = emotion_detector("I am happy")
        self.assertEqual(result["dominant_emotion"], "joy")
        self.assertEqual(set(result), {"anger", "disgust", "fear", "joy", "sadness", "dominant_emotion"})

    @patch("emotion_detection.requests.post")
    def test_dominant_sadness(self, post):
        response = Mock(status_code=200)
        response.json.return_value = {"emotionPredictions": [{"emotion": {
            "anger": 0.02, "disgust": 0.01, "fear": 0.04,
            "joy": 0.03, "sadness": 0.90}}]}
        post.return_value = response
        self.assertEqual(emotion_detector("I am sad")["dominant_emotion"], "sadness")

    @patch("emotion_detection.requests.post")
    def test_bad_request_returns_empty_values(self, post):
        post.return_value = Mock(status_code=400)
        result = emotion_detector("bad input")
        self.assertIsNone(result["dominant_emotion"])
        self.assertIsNone(result["joy"])

    @patch("emotion_detection.requests.post")
    def test_blank_input_does_not_call_service(self, post):
        result = emotion_detector("   ")
        post.assert_not_called()
        self.assertIsNone(result["dominant_emotion"])


if __name__ == "__main__":
    unittest.main()
