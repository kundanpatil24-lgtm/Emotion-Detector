"""Flask web deployment for the emotion detector."""
from flask import Flask, render_template, request
from emotion_detection import emotion_detector

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def index():
    result, error = None, None
    text_to_analyze = ""
    if request.method == "POST":
        text_to_analyze = request.form.get("textToAnalyze", "")
        if not text_to_analyze.strip():
            error = "Please enter text to analyze."
        else:
            try:
                result = emotion_detector(text_to_analyze)
                if result.get("dominant_emotion") is None:
                    error = "Emotion detection could not process this input. Please try again."
            except Exception:
                error = "Emotion detection is temporarily unavailable. Please try again."
    return render_template("index.html", result=result, error=error,
                           text_to_analyze=text_to_analyze)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
