# Emotion Detector

A Flask web application that analyzes text using the IBM Watson NLP emotion prediction endpoint and displays anger, disgust, fear, joy, sadness, and the dominant emotion.

## Files
- `emotion_detection.py`: calls the Watson NLP endpoint and formats its response.
- `server.py`: Flask app with blank-input and service-error handling.
- `templates/index.html`, `static/style.css`: browser interface.
- `EmotionDetection/`: package import shim.
- `test_emotion_detection.py`: unit tests.

## Setup
Requires Python 3.10+ and network access to the course Watson NLP endpoint.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Test
```bash
python -m unittest -v test_emotion_detection.py
```
Tests mock the remote service and do not require network access.

## Run
```bash
python server.py
```
Open http://127.0.0.1:5000.

## Static analysis
```bash
pip install pylint
pylint server.py emotion_detection.py
```
The score depends on the PyLint version and exact rubric. Run it yourself and fix any reported issues.

## Submission note
Verify the endpoint and response schema in your course lab. Capture genuine terminal output and screenshots from your own run; do not submit fabricated evidence.
